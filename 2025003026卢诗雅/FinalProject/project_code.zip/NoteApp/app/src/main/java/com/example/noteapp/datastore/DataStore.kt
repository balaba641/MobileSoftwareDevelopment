package com.example.noteapp.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_preferences")

class UserPreferencesRepository(private val context: Context) {
    // ================= 主题 =================
    private val themeModeKey = stringPreferencesKey("theme_mode")
    val themeMode: Flow<String> = context.dataStore.data
        .map { preferences -> preferences[themeModeKey] ?: "system" }
    suspend fun saveThemeMode(mode: String) {
        context.dataStore.edit { preferences -> preferences[themeModeKey] = mode }
    }

    // ================= 搜索历史 =================
    private val recentSearchKey = stringPreferencesKey("recent_search")
    val recentSearch: Flow<String> = context.dataStore.data
        .map { preferences -> preferences[recentSearchKey] ?: "" }
    suspend fun saveRecentSearch(query: String) {
        context.dataStore.edit { preferences -> preferences[recentSearchKey] = query }
    }

    // ================= 自动保存 =================
    private val autoSaveKey = booleanPreferencesKey("auto_save")
    val isAutoSaveEnabled: Flow<Boolean> = context.dataStore.data
        .map { preferences -> preferences[autoSaveKey] ?: true }
    suspend fun setAutoSave(enabled: Boolean) {
        context.dataStore.edit { preferences -> preferences[autoSaveKey] = enabled }
    }

    // ================= 用户登录状态（新增） =================
    private val userIdKey = intPreferencesKey("user_id")
    private val usernameKey = stringPreferencesKey("username")

    val userId: Flow<Int> = context.dataStore.data
        .map { preferences -> preferences[userIdKey] ?: -1 }
    val username: Flow<String> = context.dataStore.data
        .map { preferences -> preferences[usernameKey] ?: "" }

    suspend fun saveUser(userId: Int, username: String) {
        context.dataStore.edit { preferences ->
            preferences[userIdKey] = userId
            preferences[usernameKey] = username
        }
    }

    suspend fun clearUser() {
        context.dataStore.edit { preferences ->
            preferences.remove(userIdKey)
            preferences.remove(usernameKey)
        }
    }
}