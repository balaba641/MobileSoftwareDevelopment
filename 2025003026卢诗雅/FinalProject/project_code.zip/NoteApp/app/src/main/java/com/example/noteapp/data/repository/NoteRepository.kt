package com.example.noteapp.data.repository

import com.example.noteapp.data.dao.CategoryDao
import com.example.noteapp.data.dao.NoteDao
import com.example.noteapp.data.dao.UserDao
import com.example.noteapp.data.entity.CategoryEntity
import com.example.noteapp.data.entity.NoteEntity
import com.example.noteapp.data.entity.UserEntity
import com.example.noteapp.data.network.RetrofitClient
import com.example.noteapp.data.network.dto.QuoteDto
import kotlinx.coroutines.flow.Flow

class NoteRepository(
    private val noteDao: NoteDao,
    private val categoryDao: CategoryDao,
    private val userDao: UserDao
) {
    // ==================== 笔记 ====================
    fun getAllNotes(): Flow<List<NoteEntity>> = noteDao.getAllNotes()

    fun searchNotes(searchQuery: String): Flow<List<NoteEntity>> =
        noteDao.searchNotes("%$searchQuery%")

    suspend fun getNoteById(noteId: Int): NoteEntity? = noteDao.getNoteById(noteId)

    suspend fun insertNote(note: NoteEntity) = noteDao.insertNote(note)

    suspend fun updateNote(note: NoteEntity) = noteDao.updateNote(note)

    suspend fun deleteNote(note: NoteEntity) = noteDao.deleteNote(note)

    fun getNotesByCategory(categoryId: Int): Flow<List<NoteEntity>> =
        noteDao.getNotesByCategory(categoryId)

    // ==================== 分类 ====================
    suspend fun insertDefaultCategory() {
        val defaultCategory = CategoryEntity(name = "默认分类")
        categoryDao.insertCategory(defaultCategory)
    }

    suspend fun getAllCategories(): List<CategoryEntity> = categoryDao.getAllCategories()

    suspend fun insertCategory(category: CategoryEntity) = categoryDao.insertCategory(category)

    suspend fun deleteCategory(category: CategoryEntity) = categoryDao.deleteCategory(category)

    // ==================== 用户 ====================
    suspend fun login(username: String, password: String): UserEntity? =
        userDao.login(username, password)

    suspend fun register(user: UserEntity): Long = userDao.insertUser(user)

    suspend fun getUserByUsername(username: String): UserEntity? =
        userDao.getUserByUsername(username)

    suspend fun updateUser(user: UserEntity) = userDao.updateUser(user)

    suspend fun deleteUser(user: UserEntity) = userDao.deleteUser(user)

    // ==================== 网络 ====================
    suspend fun getRandomQuote(): Result<QuoteDto> {
        return try {
            val response = RetrofitClient.apiService.getRandomQuote()
            Result.success(response)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}