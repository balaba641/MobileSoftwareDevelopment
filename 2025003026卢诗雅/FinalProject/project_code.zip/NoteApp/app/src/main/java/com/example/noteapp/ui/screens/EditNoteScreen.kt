package com.example.noteapp.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.example.noteapp.viewmodel.NoteViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditNoteScreen(
    navController: NavController,
    noteId: Int,
    viewModel: NoteViewModel
) {
    val editState by viewModel.editNoteUiState.collectAsStateWithLifecycle()
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    var categoryExpanded by remember { mutableStateOf(false) }

    // 新建分类对话框
    var showNewCategoryDialog by remember { mutableStateOf(false) }
    var newCategoryName by remember { mutableStateOf("") }

    // 删除分类对话框
    var showDeleteCategoryDialog by remember { mutableStateOf(false) }

    LaunchedEffect(noteId) {
        if (noteId == 0) {
            viewModel.resetEditState()
        } else {
            viewModel.loadNoteById(noteId)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (noteId == 0) "新建笔记" else "编辑笔记") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "返回")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = editState.title,
                onValueChange = { viewModel.updateEditNoteField(title = it) },
                label = { Text("笔记标题*") },
                modifier = Modifier.fillMaxWidth(),
                isError = editState.isTitleError,
                supportingText = { if (editState.isTitleError) Text("标题不能为空") },
                singleLine = true
            )

            OutlinedTextField(
                value = editState.content,
                onValueChange = { viewModel.updateEditNoteField(content = it) },
                label = { Text("笔记内容*") },
                modifier = Modifier.fillMaxWidth(),
                isError = editState.isContentError,
                supportingText = { if (editState.isContentError) Text("内容不能为空") },
                maxLines = 8
            )

            // 分类选择 + 新建 + 删除
            if (categories.isNotEmpty()) {
                ExposedDropdownMenuBox(
                    expanded = categoryExpanded,
                    onExpandedChange = { categoryExpanded = !categoryExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = categories.find { it.id == editState.categoryId }?.name ?: "",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("分类") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                        modifier = Modifier.menuAnchor(),
                        // 修改：使用 background 与页面背景一致
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.background,
                            unfocusedContainerColor = MaterialTheme.colorScheme.background,
                            disabledContainerColor = MaterialTheme.colorScheme.background
                        )
                    )
                    ExposedDropdownMenu(
                        expanded = categoryExpanded,
                        onDismissRequest = { categoryExpanded = false },
                        modifier = Modifier.background(MaterialTheme.colorScheme.background)
                    ) {
                        categories.forEach { category ->
                            DropdownMenuItem(
                                text = { Text(category.name) },
                                onClick = {
                                    viewModel.updateEditNoteField(categoryId = category.id)
                                    categoryExpanded = false
                                }
                            )
                        }
                        Divider()
                        // 新建分类
                        DropdownMenuItem(
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Add, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("新建分类")
                                }
                            },
                            onClick = {
                                categoryExpanded = false
                                showNewCategoryDialog = true
                            }
                        )
                        // 删除分类（不允许删除默认分类 ID=1）
                        if (editState.categoryId != 1) {
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("删除当前分类", color = MaterialTheme.colorScheme.error)
                                    }
                                },
                                onClick = {
                                    categoryExpanded = false
                                    showDeleteCategoryDialog = true
                                }
                            )
                        }
                    }
                }
            }

            OutlinedTextField(
                value = editState.imageUrl ?: "",
                onValueChange = { viewModel.updateEditNoteField(imageUrl = it.ifBlank { null }) },
                label = { Text("配图链接（选填）") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Button(
                onClick = {
                    viewModel.saveNote()
                    navController.popBackStack()
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = !editState.isSaving,
                shape = MaterialTheme.shapes.medium
            ) {
                Icon(Icons.Default.Save, contentDescription = "保存")
                Text("保存笔记", modifier = Modifier.padding(start = 8.dp))
            }
        }
    }

    // ---------- 新建分类对话框（背景使用 background） ----------
    if (showNewCategoryDialog) {
        AlertDialog(
            onDismissRequest = { showNewCategoryDialog = false },
            title = { Text("新建分类") },
            text = {
                OutlinedTextField(
                    value = newCategoryName,
                    onValueChange = { newCategoryName = it },
                    label = { Text("分类名称") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (newCategoryName.isNotBlank()) {
                            viewModel.insertCategory(newCategoryName)
                            showNewCategoryDialog = false
                            newCategoryName = ""
                        }
                    }
                ) {
                    Text("确定")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showNewCategoryDialog = false
                    newCategoryName = ""
                }) {
                    Text("取消")
                }
            },
            containerColor = MaterialTheme.colorScheme.background
        )
    }

    // ---------- 删除分类确认对话框（背景使用 background） ----------
    if (showDeleteCategoryDialog) {
        val categoryName = categories.find { it.id == editState.categoryId }?.name ?: ""
        AlertDialog(
            onDismissRequest = { showDeleteCategoryDialog = false },
            title = { Text("删除分类") },
            text = { Text("确定要删除分类“$categoryName”吗？该分类下的笔记将被移至“默认分类”。") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteCategory(editState.categoryId)
                        showDeleteCategoryDialog = false
                    }
                ) {
                    Text("确定", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteCategoryDialog = false }) {
                    Text("取消")
                }
            },
            containerColor = MaterialTheme.colorScheme.background
        )
    }
}