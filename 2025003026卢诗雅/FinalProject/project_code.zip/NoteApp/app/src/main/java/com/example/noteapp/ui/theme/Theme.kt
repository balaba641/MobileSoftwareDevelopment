package com.example.noteapp.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = Red500,                     // 顶部栏、FAB、按钮 → 标准玫红
    onPrimary = Color.White,
    primaryContainer = Red100,            // 卡片容器底色 → 浅粉
    onPrimaryContainer = Red900,
    secondary = Red400,                   // 辅助色 → 亮玫红
    onSecondary = Color.White,
    secondaryContainer = Red50,           // 背景色已经在下面设置，这里为容器背景
    onSecondaryContainer = Red800,
    background = Red50,                   // 页面背景 → 极浅粉（红粉基调）
    onBackground = Neutral900,
    surface = Color.White,                // 卡片、输入框表面 → 白色
    onSurface = Neutral800,
    error = Red500,
    onError = Color.White
)

private val DarkColorScheme = darkColorScheme(
    primary = DarkRed500,                 // 深色模式顶部栏 → 亮玫红
    onPrimary = Color.White,
    primaryContainer = DarkRed200,
    onPrimaryContainer = DarkRed50,
    secondary = DarkRed400,
    onSecondary = Color.White,
    secondaryContainer = DarkRed100,
    onSecondaryContainer = DarkRed50,
    background = Neutral950,              // 深色背景 → 近黑
    onBackground = Neutral100,
    surface = Neutral800,                 // 深色卡片 → 深灰
    onSurface = Neutral100,
    error = DarkRed500,
    onError = Color.White
)

@Composable
fun NoteAppTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,        // 改为 false，强制使用我们的配色（红粉主题）
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        // 若 dynamicColor 为 true 且系统支持，则使用动态颜色（但此处已设为 false，故此分支不会进入）
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.primary.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}