package com.example.noteapp.viewmodel

import com.example.noteapp.data.entity.NoteEntity
import com.example.noteapp.data.entity.UserEntity
import com.example.noteapp.data.network.dto.QuoteDto

sealed interface NoteUiState {
    object Loading : NoteUiState
    data class Success(val notes: List<NoteEntity>) : NoteUiState
    data class Error(val message: String) : NoteUiState
    object Empty : NoteUiState
}

sealed interface QuoteUiState {
    object Loading : QuoteUiState
    data class Success(val quote: QuoteDto) : QuoteUiState
    data class Error(val message: String) : QuoteUiState
}

data class EditNoteUiState(
    val noteId: Int = 0,
    val title: String = "",
    val content: String = "",
    val categoryId: Int = 1,
    val imageUrl: String? = null,
    val isTitleError: Boolean = false,
    val isContentError: Boolean = false,
    val isSaving: Boolean = false
)

sealed interface LoginUiState {
    object Idle : LoginUiState
    object Loading : LoginUiState
    data class Success(val user: UserEntity) : LoginUiState
    data class Error(val message: String) : LoginUiState
}

sealed interface RegisterUiState {
    object Idle : RegisterUiState
    object Loading : RegisterUiState
    object Success : RegisterUiState
    data class Error(val message: String) : RegisterUiState
}