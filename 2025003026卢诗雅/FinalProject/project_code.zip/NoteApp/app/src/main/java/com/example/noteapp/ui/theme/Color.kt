package com.example.noteapp.ui.theme

import androidx.compose.ui.graphics.Color

// ========== 红色→玫粉色系（浅色模式） ==========
val Red50 = Color(0xFFFFF0F5)   // 极浅粉（背景用）
val Red100 = Color(0xFFFFD6E0)  // 浅粉（容器底色）
val Red200 = Color(0xFFF8A4B8)  // 粉红
val Red300 = Color(0xFFF47A9A)  // 中玫粉
val Red400 = Color(0xFFEC4C7A)  // 亮玫红（高亮）
val Red500 = Color(0xFFE91E63)  // 标准玫红（导航栏、按钮）
val Red600 = Color(0xFFD81B60)  // 深玫红（按压态）
val Red700 = Color(0xFFC2185B)  // 更深玫红
val Red800 = Color(0xFFAD1457)  // 紫红（强调）
val Red900 = Color(0xFF880E4F)  // 极暗紫红

// ========== 红色→玫粉色系（深色模式） ==========
val DarkRed50 = Color(0xFF2A0A12)
val DarkRed100 = Color(0xFF3E0F1C)
val DarkRed200 = Color(0xFF5A1829)
val DarkRed300 = Color(0xFF7A1F38)
val DarkRed400 = Color(0xFF9C2647)
val DarkRed500 = Color(0xFFD42A54)  // 深色模式主色（亮玫红）

// ========== 中性色（背景/表面/文本） ==========
val Neutral50 = Color(0xFFFAFAFA)
val Neutral100 = Color(0xFFF5F5F5)
val Neutral200 = Color(0xFFEEEEEE)
val Neutral800 = Color(0xFF424242)
val Neutral900 = Color(0xFF212121)
val Neutral950 = Color(0xFF121212)