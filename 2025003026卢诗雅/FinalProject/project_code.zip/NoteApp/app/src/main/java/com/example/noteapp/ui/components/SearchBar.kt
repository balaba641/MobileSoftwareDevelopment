package com.example.noteapp.ui.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.noteapp.viewmodel.NoteViewModel
import kotlinx.coroutines.delay

@Composable
fun SearchBar(
    modifier: Modifier = Modifier,
    viewModel: NoteViewModel
) {
    var searchText by remember { mutableStateOf("") }

    LaunchedEffect(searchText) {
        delay(500)
        viewModel.updateSearchQuery(searchText)
    }

    OutlinedTextField(
        value = searchText,
        onValueChange = { searchText = it },
        label = { Text("搜索笔记") },
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        placeholder = { Text("输入标题/内容搜索") },
        singleLine = true
    )
}