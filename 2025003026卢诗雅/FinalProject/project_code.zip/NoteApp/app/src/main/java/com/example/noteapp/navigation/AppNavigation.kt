package com.example.noteapp.navigation

import android.annotation.SuppressLint
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.noteapp.data.database.AppDatabase
import com.example.noteapp.data.repository.NoteRepository
import com.example.noteapp.datastore.UserPreferencesRepository
import com.example.noteapp.ui.screens.*
import com.example.noteapp.viewmodel.NoteViewModel
import com.example.noteapp.viewmodel.NoteViewModelFactory

@SuppressLint("StateFlowValueCalledInComposition")
@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val context = androidx.compose.ui.platform.LocalContext.current

    val database = AppDatabase.getDatabase(context)
    val noteRepository = remember { NoteRepository(database.noteDao(), database.categoryDao(), database.userDao()) }
    val userPreferencesRepository = remember { UserPreferencesRepository(context) }
    val viewModelFactory = remember {
        NoteViewModelFactory(noteRepository, userPreferencesRepository)
    }
    val noteViewModel: NoteViewModel = viewModel(factory = viewModelFactory)

    val startDestination = if (noteViewModel.isLoggedIn.value) "home" else "login"

    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable("login") {
            LoginScreen(navController, noteViewModel)
        }
        composable("register") {
            RegisterScreen(navController, noteViewModel)
        }
        composable("home") {
            HomeScreen(navController, noteViewModel)
        }
        composable("note_detail/{noteId}") { backStackEntry ->
            val noteId = backStackEntry.arguments?.getString("noteId")?.toInt() ?: 0
            NoteDetailScreen(navController, noteId, noteViewModel)
        }
        composable("edit_note/{noteId}?") { backStackEntry ->
            val noteId = backStackEntry.arguments?.getString("noteId")?.toInt() ?: 0
            EditNoteScreen(navController, noteId, noteViewModel)
        }
        composable("settings") {
            SettingsScreen(navController, noteViewModel)
        }
        composable("profile") {
            ProfileScreen(navController, noteViewModel)
        }
    }
}