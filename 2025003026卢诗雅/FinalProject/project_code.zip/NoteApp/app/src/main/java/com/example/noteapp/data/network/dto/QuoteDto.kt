package com.example.noteapp.data.network.dto

data class QuoteDto(
    val id: Int,
    val quote: String,
    val author: String,
    val tags: List<String>
)