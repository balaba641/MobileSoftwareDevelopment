package com.example.noteapp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.noteapp.data.entity.CategoryEntity
import com.example.noteapp.data.entity.NoteEntity
import com.example.noteapp.data.entity.UserEntity
import com.example.noteapp.data.repository.NoteRepository
import com.example.noteapp.datastore.UserPreferencesRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class NoteViewModel(
    private val noteRepository: NoteRepository,
    private val userPreferencesRepository: UserPreferencesRepository
) : ViewModel() {

    // ================= 笔记 =================
    private val _noteUiState = MutableStateFlow<NoteUiState>(NoteUiState.Loading)
    val noteUiState: StateFlow<NoteUiState> = _noteUiState.asStateFlow()

    private val _editNoteUiState = MutableStateFlow(EditNoteUiState())
    val editNoteUiState: StateFlow<EditNoteUiState> = _editNoteUiState.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // ================= 分类 =================
    private val _categories = MutableStateFlow<List<CategoryEntity>>(emptyList())
    val categories: StateFlow<List<CategoryEntity>> = _categories.asStateFlow()

    private val _selectedCategoryId = MutableStateFlow<Int?>(null)
    val selectedCategoryId: StateFlow<Int?> = _selectedCategoryId.asStateFlow()

    private val _deleteCategoryError = MutableStateFlow<String?>(null)
    val deleteCategoryError: StateFlow<String?> = _deleteCategoryError.asStateFlow()

    // ================= 名言 =================
    private val _quoteUiState = MutableStateFlow<QuoteUiState>(QuoteUiState.Loading)
    val quoteUiState: StateFlow<QuoteUiState> = _quoteUiState.asStateFlow()

    // ================= 用户 =================
    private val _loginUiState = MutableStateFlow<LoginUiState>(LoginUiState.Idle)
    val loginUiState: StateFlow<LoginUiState> = _loginUiState.asStateFlow()

    private val _registerUiState = MutableStateFlow<RegisterUiState>(RegisterUiState.Idle)
    val registerUiState: StateFlow<RegisterUiState> = _registerUiState.asStateFlow()

    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    val isLoggedIn: StateFlow<Boolean> = userPreferencesRepository.userId
        .map { it != -1 }
        .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    init {
        refreshCategories()
        loadNotes()
        viewModelScope.launch {
            val cats = noteRepository.getAllCategories()
            if (cats.isEmpty()) {
                noteRepository.insertDefaultCategory()
                refreshCategories()
            }
        }
        viewModelScope.launch {
            val userId = userPreferencesRepository.userId.first()
            if (userId != -1) {
                val username = userPreferencesRepository.username.first()
                val user = noteRepository.getUserByUsername(username)
                _currentUser.value = user
            }
        }
    }

    // ---- 笔记 ----
    fun loadNotes() {
        viewModelScope.launch {
            _noteUiState.value = NoteUiState.Loading
            val categoryId = _selectedCategoryId.value
            val flow = if (categoryId == null) {
                noteRepository.getAllNotes()
            } else {
                noteRepository.getNotesByCategory(categoryId)
            }
            flow.collect { notes ->
                _noteUiState.value = if (notes.isEmpty()) NoteUiState.Empty
                else NoteUiState.Success(notes)
            }
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
        viewModelScope.launch {
            _noteUiState.value = NoteUiState.Loading
            noteRepository.searchNotes(query).collect { notes ->
                _noteUiState.value = if (notes.isEmpty()) NoteUiState.Empty
                else NoteUiState.Success(notes)
            }
            userPreferencesRepository.saveRecentSearch(query)
        }
    }

    fun loadNoteById(noteId: Int) {
        viewModelScope.launch {
            val note = noteRepository.getNoteById(noteId)
            note?.let {
                _editNoteUiState.update { state ->
                    state.copy(
                        noteId = it.id,
                        title = it.title,
                        content = it.content,
                        categoryId = it.categoryId,
                        imageUrl = it.imageUrl
                    )
                }
            }
        }
    }

    fun resetEditState() {
        _editNoteUiState.value = EditNoteUiState()
    }

    fun updateEditNoteField(
        title: String = _editNoteUiState.value.title,
        content: String = _editNoteUiState.value.content,
        categoryId: Int = _editNoteUiState.value.categoryId,
        imageUrl: String? = _editNoteUiState.value.imageUrl
    ) {
        _editNoteUiState.update { state ->
            state.copy(
                title = title,
                content = content,
                categoryId = categoryId,
                imageUrl = imageUrl,
                isTitleError = title.isBlank(),
                isContentError = content.isBlank()
            )
        }
    }

    fun saveNote() {
        val currentState = _editNoteUiState.value
        if (currentState.title.isBlank() || currentState.content.isBlank()) {
            _editNoteUiState.update {
                it.copy(
                    isTitleError = currentState.title.isBlank(),
                    isContentError = currentState.content.isBlank()
                )
            }
            return
        }

        viewModelScope.launch {
            _editNoteUiState.update { it.copy(isSaving = true) }
            val note = NoteEntity(
                id = currentState.noteId,
                title = currentState.title,
                content = currentState.content,
                categoryId = currentState.categoryId,
                imageUrl = currentState.imageUrl,
                updatedAt = System.currentTimeMillis() / 1000
            )
            if (currentState.noteId == 0) {
                noteRepository.insertNote(note)
            } else {
                noteRepository.updateNote(note)
            }
            _editNoteUiState.update { it.copy(isSaving = false) }
            loadNotes()
        }
    }

    fun deleteNote(note: NoteEntity) {
        viewModelScope.launch {
            noteRepository.deleteNote(note)
            loadNotes()
        }
    }

    fun togglePin(note: NoteEntity) {
        viewModelScope.launch {
            val updated = note.copy(isPinned = !note.isPinned)
            noteRepository.updateNote(updated)
            loadNotes()
        }
    }

    // ---- 分类 ----
    fun refreshCategories() {
        viewModelScope.launch {
            val list = noteRepository.getAllCategories()
            _categories.value = list
            if (_selectedCategoryId.value != null && list.none { it.id == _selectedCategoryId.value }) {
                _selectedCategoryId.value = null
            }
        }
    }

    fun selectCategory(categoryId: Int?) {
        _selectedCategoryId.value = categoryId
        loadNotes()
    }

    fun insertCategory(name: String) {
        viewModelScope.launch {
            val newCategory = CategoryEntity(name = name)
            noteRepository.insertCategory(newCategory)
            refreshCategories()
            val updatedList = _categories.value
            val newCat = updatedList.find { it.name == name }
            newCat?.let {
                _selectedCategoryId.value = it.id
                _editNoteUiState.update { state -> state.copy(categoryId = it.id) }
            }
        }
    }

    fun deleteCategory(categoryId: Int) {
        viewModelScope.launch {
            _deleteCategoryError.value = null

            val categories = _categories.value
            val category = categories.find { it.id == categoryId }
            if (category == null) {
                _deleteCategoryError.value = "分类不存在"
                return@launch
            }

            val defaultCategory = categories.find { it.name == "默认分类" }
            if (defaultCategory == null) {
                _deleteCategoryError.value = "默认分类不存在，请先创建默认分类"
                return@launch
            }

            if (category.name == "默认分类") {
                _deleteCategoryError.value = "默认分类不能删除"
                return@launch
            }

            val notes = noteRepository.getNotesByCategory(categoryId).firstOrNull() ?: emptyList()
            if (notes.isNotEmpty()) {
                notes.forEach { note ->
                    val updatedNote = note.copy(categoryId = defaultCategory.id)
                    noteRepository.updateNote(updatedNote)
                }
            }

            noteRepository.deleteCategory(category)
            refreshCategories()
            if (_selectedCategoryId.value == categoryId) {
                _selectedCategoryId.value = null
                loadNotes()
            }
            if (_editNoteUiState.value.categoryId == categoryId) {
                _editNoteUiState.update { state -> state.copy(categoryId = defaultCategory.id) }
            }
        }
    }

    // ---- 名言 ----
    fun getRandomQuote() {
        viewModelScope.launch {
            _quoteUiState.value = QuoteUiState.Loading
            val result = noteRepository.getRandomQuote()
            _quoteUiState.value = result.fold(
                onSuccess = { QuoteUiState.Success(it) },
                onFailure = { QuoteUiState.Error(it.message ?: "获取灵感失败") }
            )
        }
    }

    // ---- 用户 ----
    fun login(username: String, password: String) {
        viewModelScope.launch {
            _loginUiState.value = LoginUiState.Loading
            val user = noteRepository.login(username, password)
            if (user != null) {
                userPreferencesRepository.saveUser(user.id, user.username)
                _currentUser.value = user
                _loginUiState.value = LoginUiState.Success(user)
            } else {
                _loginUiState.value = LoginUiState.Error("用户名或密码错误")
            }
        }
    }

    fun register(username: String, password: String) {
        viewModelScope.launch {
            _registerUiState.value = RegisterUiState.Loading
            val existing = noteRepository.getUserByUsername(username)
            if (existing != null) {
                _registerUiState.value = RegisterUiState.Error("用户名已存在")
                return@launch
            }
            val user = UserEntity(username = username, password = password)
            val id = noteRepository.register(user)
            if (id > 0) {
                _registerUiState.value = RegisterUiState.Success
            } else {
                _registerUiState.value = RegisterUiState.Error("注册失败，请重试")
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            userPreferencesRepository.clearUser()
            _currentUser.value = null
            _loginUiState.value = LoginUiState.Idle
        }
    }

    fun loadCurrentUser() {
        viewModelScope.launch {
            val userId = userPreferencesRepository.userId.first()
            if (userId != -1) {
                val username = userPreferencesRepository.username.first()
                val user = noteRepository.getUserByUsername(username)
                _currentUser.value = user
            }
        }
    }

    // ---- 设置 ----
    fun saveThemeMode(mode: String) {
        viewModelScope.launch {
            userPreferencesRepository.saveThemeMode(mode)
        }
    }

    fun setAutoSave(enabled: Boolean) {
        viewModelScope.launch {
            userPreferencesRepository.setAutoSave(enabled)
        }
    }

    fun clearDeleteCategoryError() {
        _deleteCategoryError.value = null
    }

    // ==================== 修改资料（用户名、昵称、密码） ====================
    // 修改：新密码不再限制长度，只要求与确认密码一致
    fun updateProfile(
        newUsername: String,
        newNickname: String,
        currentPassword: String,
        newPassword: String,
        confirmPassword: String,
        onError: (String) -> Unit,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val currentUser = _currentUser.value
            if (currentUser == null) {
                onError("未登录")
                return@launch
            }

            // 1. 验证用户名
            if (newUsername.isBlank()) {
                onError("用户名不能为空")
                return@launch
            }

            // 2. 验证当前密码
            if (currentPassword.isBlank()) {
                onError("请输入当前密码")
                return@launch
            }
            if (currentUser.password != currentPassword) {
                onError("当前密码错误")
                return@launch
            }

            // 3. 检查用户名是否被其他用户占用（排除自己）
            val existingUser = noteRepository.getUserByUsername(newUsername)
            if (existingUser != null && existingUser.id != currentUser.id) {
                onError("用户名已被占用")
                return@launch
            }

            // 4. 验证新密码（如果填写了）
            if (newPassword.isNotBlank()) {
                // 已移除长度限制，只需与确认密码一致
                if (newPassword != confirmPassword) {
                    onError("新密码和确认密码不一致")
                    return@launch
                }
            } else {
                // 新密码为空，确认密码也必须为空
                if (confirmPassword.isNotBlank()) {
                    onError("确认密码应留空或不填")
                    return@launch
                }
            }

            // 5. 更新用户信息
            val updatedUser = currentUser.copy(
                username = newUsername,
                nickname = newNickname.ifBlank { null },
                password = if (newPassword.isNotBlank()) newPassword else currentUser.password
            )
            noteRepository.updateUser(updatedUser)
            _currentUser.value = updatedUser

            // 6. 如果用户名变了，更新 DataStore
            if (newUsername != currentUser.username) {
                userPreferencesRepository.saveUser(updatedUser.id, newUsername)
            }

            onSuccess()
        }
    }

    // ========== 保留旧方法（兼容） ==========
    fun updateNickname(newNickname: String) {
        viewModelScope.launch {
            val current = _currentUser.value
            if (current != null && newNickname.isNotBlank()) {
                val updatedUser = current.copy(nickname = newNickname)
                noteRepository.updateUser(updatedUser)
                _currentUser.value = updatedUser
            }
        }
    }

    fun deleteAccount() {
        viewModelScope.launch {
            val current = _currentUser.value ?: return@launch
            val allNotes = noteRepository.getAllNotes().firstOrNull() ?: emptyList()
            allNotes.forEach { note ->
                noteRepository.deleteNote(note)
            }
            noteRepository.deleteUser(current)
            userPreferencesRepository.clearUser()
            _currentUser.value = null
            _loginUiState.value = LoginUiState.Idle
        }
    }
}

class NoteViewModelFactory(
    private val noteRepository: NoteRepository,
    private val userPreferencesRepository: UserPreferencesRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(NoteViewModel::class.java)) {
            return NoteViewModel(noteRepository, userPreferencesRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}