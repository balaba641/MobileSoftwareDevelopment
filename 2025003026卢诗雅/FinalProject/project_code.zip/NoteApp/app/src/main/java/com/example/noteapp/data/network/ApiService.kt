package com.example.noteapp.data.network

import com.example.noteapp.data.network.dto.QuoteDto
import retrofit2.http.GET

interface ApiService {
    @GET("quotes/random")
    suspend fun getRandomQuote(): QuoteDto
}